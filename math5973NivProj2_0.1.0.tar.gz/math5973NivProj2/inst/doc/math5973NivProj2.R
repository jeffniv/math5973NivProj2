## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(math5973NivProj2)

## ----embed--------------------------------------------------------------------
obj=ssa(co2,18) #using the Keeling CO2 curve
obj$X[,1:10] #first few columns 

## ----svd,  R.options=list(max.print=30)---------------------------------------
print(obj$X.svd)

## ----print, echo=FALSE--------------------------------------------------------
print(obj)

## ----summary, echo=FALSE------------------------------------------------------
summary(obj)

## ----detrend,eval=FALSE-------------------------------------------------------
#  reconstruct(obj,pcs=2:obj$window.length,plot=T)

## ----period, eval=FALSE-------------------------------------------------------
#  reconstruct(obj, pcs=2:5)

